 
echo ""
echo "
███╗   ███╗ █████╗ ██████╗ ██╗  ██╗
████╗ ████║██╔══██╗██╔══██╗██║ ██╔╝
██╔████╔██║███████║██████╔╝█████╔╝ 
██║╚██╔╝██║██╔══██║██╔══██╗██╔═██╗ 
██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██╗
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
                                   
                                   "
echo ""
echo ""
echo "Your Device Info"
echo ""
sleep 0.5
echo "ID Device    > $(getprop ro.product.model)"
sleep 0.5
echo "ID Brand     > $(getprop ro.product.system.brand)"
sleep 0.5
echo "ID Model     > $(getprop ro.build.product)"
sleep 0.5
echo "ID Kernel    > $(uname -r)"
sleep 0.5
echo "ID Chipset   > $(getprop ro.product.board)"
echo ""
sleep 2
echo ""
echo "____________________"
echo "Creator @acewilhear"
echo ""

sleep 1

echo "______________________"
echo "Special Thanks"
echo "@RiProG @Kurodenshiii"
echo ""

sleep 1

echo ""
echo "Installing MARK V2"
echo ""
apply_mark() {
setprop debug.hwui.renderer skiagl
setprop debug.renderengine.backend skiagl
setprop debug.performance_schema 1
setprop debug.performance_schema_max_memory_classes 320
setprop debug.performance_schema_max_socket_classes 10
setprop debug.composition.type mdp
setprop debug.composition.type2 gpu
setprop debug.gr.swapinterval 0
setprop debug.systemuicompilerfilter speed
setprop debug.rs.precision rs_fp_full
setprop debug.sf.latch_unsignaled 0
setprop debug.sf.disable_backpressure 1
setprop debug.hwui.disabledither false
setprop debug.sf.hw 1
setprop debug.sf.enable_hgl 1
setprop debug.sf.ddms 1
setprop debug.disable.hwacc 0
setprop debug.disable_sched_boost true
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.default-GPU-driver 1
setprop debug.MB.inner.running 37
setprop debug.stagefright.omx_google.codecs 0
setprop debug.MB.running 23
setprop debug.hwc.compose_level 0
setprop debug.hwui.render_dirty_regions false
setprop debug.mdlogger.Running 0
setprop debug.hwc.bq_count 3
setprop debug.lldb-rpc-server 0
setprop debug.choreographer.skipwarning 16
setprop debug.choreographer.callback 120
setprop debug.hwui.disable_draw_defer true
setprop debug.hwui.enable_partial_updates true
setprop debug.multicore.processing 1
setprop debug.hwui.disable_draw_reorder true
setprop debug.hwui.skip_empty_damage true
setprop debug.perfhudes 1
setprop debug.sf.enable_hgl 1
setprop debug.sf.showupdates 0
setprop debug.sf.showbackground 0
setprop debug.sf.showfps 0
setprop debug.dev.ssrm.turbo true
setprop debug.dev.disable_sched_boost true
setprop debug.rs.default-CPU-buffer 262144
setprop debug.fw.bservice_enable 1
setprop debug.egl.profiler 0
setprop debug.enabletr true
setprop debug.overlayui.enable 1
setprop debug.atrace.app_number 1
setprop debug.assert 1
setprop debug.sf.showcpu 0
setprop debug.egl.hw 0
setprop debug.kill_allocating_task 1
setprop debug.hwui.fps_divisor -1
setprop debug.cpurend.vsync false
setprop debug.gpurend.vsync true
setprop debug.power_management_mode pref_max
setprop debug.mdpcomp.maxpermixer 0
setprop debug.performance.tuning 1
setprop debug.hal_client_domain hal_vperf
setprop debug.cpuprio 7
setprop debug.gpuprio 7
setprop debug.ioprio 7
setprop debug.hwui.target_cpu_time_percent 100
setprop debug.hwui.target_gpu_time_percent 100
setprop debug.hwui.use_hint_manager 1
setprop debug.renderer.process compound
setprop debug.qsg_renderer 1
setprop debug.performance.disturb false
setprop debug.sf.frame_rate_multiple_threshold 999
setprop debug.sf_frame_rate_multiple_fences 999
setprop debug.egl.force_msaa false
setprop debug.egl.force_fxaa false
setprop debug.egl.force_taa false
setprop debug.egl.force_ssaa false
setprop debug.egl.force_smaa false
setprop debug.gpu.scheduler_pre.emption 1
setprop debug.heat_suppression 0
setprop debug.redroid.fps 60
setprop debug.dev.addfree 4
setprop debug.gfx.driver 1
setprop debug.performance_schema_digests_size 9950000
setprop debug.show_refresh_rate_overlay_spinner 0
setprop debug.sf.max_igbp_list_size 0
setprop debug.sf.kernel_idle_timer_update_overlay true
setprop debug.sf.support_kernel_idle_timer_enabled false
setprop debug.sf.predict_hwc_composition_strategy 1
setprop debug.sf.enable_transaction_tracing true
setprop debug.sf.show_predicted_vsync false
setprop debug.sf.vsync_reactor_ignore_present_fences false
setprop debug.gralloc.gfx_ubwc_disable false
setprop debug.mdpcomp.mixedmode.disable false
setprop debug.mdpcomp.maxpermixer -1
setprop debug.sf_frame_rate_multiple_fences 999
setprop debug.sf.early.app.duration 16600000
setprop debug.sf.early.sf.duration 16600000
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.earlyGl.sf.duration 16600000
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000
setprop debug.sf.hw 1
setprop debug.sf.perf_fps_early_gl_phase_offset_ns 12000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
setprop debug.stagefright.c2inputsurface -1
setprop debug.stagefright.ccodec 4
setprop debug.stagefright.omx_default_rank 512
setprop debug.sf.hwc.min.duration 0
setprop debug.scenegraph.batching_performance 1
setprop debug.sf.disable_client_composition_cache 1
setprop debug.gralloc.map_fb_memory 0
setprop debug.egl.callstack 0
setprop debug.angle.backend 2
setprop debug.egl.native_scaling false
settings put global job_scheduler_constants 1
settings put global animator_duration_scale 0.5
settings put global transition_animation_scale 0.5
settings put global window_animation_scale 0.5
settings put system peak_refresh_rate 1
settings put global zen_mode 0
settings put global activity_manager_constants max_cached_processes 1024
settings put global fstrim_mandatory_interval 864000000
settings put global dev.pm.dyn_samplingrate 1
settings put global hwui.disable_vsync true
settings put global force_hw_ui true
settings put global persist.sampling_profiler 0
settings put global persist.sys.pugerable_assets 1
settings put global touch.pressure.scale 0.001
settings put system persist.sys.scrollingcache 3
cmd thermalservice override-status 0
cmd power set-fixed-performance-mode-enabled true
cmd activity kill-all
}
apply_mark > /dev/null 2>&1
sleep 3

echo ""
echo "Mark V2 Installed"
echo ""

sleep 1

echo ""
echo "DON'T REBOOT!!!"
echo "Thanks for using this module"
echo ""
echo "Kritik atau saran chat @acewilhear"
echo ""
echo ""
