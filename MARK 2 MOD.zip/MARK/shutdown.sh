 
echo ""
echo "
███╗   ███╗ █████╗ ██████╗ ██╗  ██╗
████╗ ████║██╔══██╗██╔══██╗██║ ██╔╝
██╔████╔██║███████║██████╔╝█████╔╝ 
██║╚██╔╝██║██╔══██║██╔══██╗██╔═██╗ 
██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██╗
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
                                   
                                   "
echo ""
echo ""
echo "Your Device Info"
echo ""
sleep 0.5
echo "ID Device    > $(getprop ro.product.model)"
sleep 0.5
echo "ID Brand     > $(getprop ro.product.system.brand)"
sleep 0.5
echo "ID Model     > $(getprop ro.build.product)"
sleep 0.5
echo "ID Kernel    > $(uname -r)"
sleep 0.5
echo "ID Chipset   > $(getprop ro.product.board)"
echo ""
sleep 2
echo ""
echo "____________________"
echo "Creator @acewilhear"
echo ""

sleep 1

echo "______________________"
echo "Special Thanks"
echo "@RiProG @Kurodenshiii"
echo ""

sleep 1

echo ""
echo "Uninstalling MARK V2"
echo ""
unapply_mark() {
setprop debug.egl.native_scaling
settings delete global job_scheduler_constants
settings delete global animator_duration_scale
settings delete global transition_animation_scale
settings delete global window_animation_scale
settings delete system peak_refresh_rate
settings delete global zen_mode
settings delete global activity_manager_constants max_cached_processes
settings delete global fstrim_mandatory_interval
settings delete global dev.pm.dyn_samplingrate
settings delete global hwui.disable_vsync
settings delete global force_hw_ui
settings delete global persist.sampling_profiler
settings delete global persist.sys.pugerable_assets
settings delete global touch.pressure.scale
settings delete system persist.sys.scrollingcache
cmd thermalservice override-status
cmd power set-fixed-performance-mode-enabled false
cmd activity kill-all
}
unapply_mark > /dev/null 2>&1
sleep 3

echo ""
echo "Mark V2 Uninstalled"
echo ""

sleep 1

echo ""
echo "REBOOT!!!"
echo "Thanks for using this module"
echo ""
echo "Kritik atau saran chat @acewilhear"
echo ""
echo ""
